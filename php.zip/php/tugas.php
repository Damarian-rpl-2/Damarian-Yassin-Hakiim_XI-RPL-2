<?php
// Menampilkan nama
$nama = "Damarian Yassin Hakiim";
// Menampilkan umur
$umur = 17;
// Menampilkan sekolah
$sekolah = "SMKN 2 Bandung";
// Menampilkan cita-cita
$cita_cita = "ingin menjadi orang kaya";

// Menampilkan informasi profile
echo "<h1>Profile</h1>";
echo "Nama: $nama<br>";
echo "Umur: $umur tahun<br>";
echo "Sekolah: $sekolah<br>";
echo "Cita-cita: $cita_cita<br>";
?>